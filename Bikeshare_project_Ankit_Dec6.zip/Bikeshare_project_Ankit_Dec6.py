#!/usr/bin/env python
# coding: utf-8

# In[1]:


import time
import pandas as pd
import numpy as np

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }


# In[2]:


def get_filters ():
    print('Hello! Let\'s explore some US bikeshare data!')
    city = input ('Enter city to analyze ')
    month = input ('Enter the month name or all ')
    day = input ('Enter day of the week or all ')
    print ('loading the data of ', city + ' city of the month ' , month + ' of ', day )
    print('-'*40)
    return city, month, day


# In[3]:


def load_data (city, month, day):
    path = (r"C:\\Users\\shree\\Downloads\\all-project-files\\" + city + ".csv")
    df = pd.read_csv (path)
    df['Start Time'] = pd.to_datetime (df['Start Time'])
    if (month != 'all') & (day != 'all'):
        df = df.loc[(df['Start Time'].dt.day_name()==  day) | (df['Start Time'].dt.month_name() == month)]
    elif (month != 'all') & (day == 'all') :
        df = df.loc[(df['Start Time'].dt.month_name() == month)]
    elif (month == 'all') & (day != 'all') :
        df = df.loc[(df['Start Time'].dt.day_name()==  day)] 
    return df    


# In[4]:


def time_stats(df):
    start_time = time.time()
    print ('The most common month: ', df['Start Time'].dt.month_name(). value_counts(). idxmax())
    print ('The most common day of the week: ' , df['Start Time'].dt.day_name(). value_counts(). idxmax())
    print ('The most common hour: ', df['Start Time'].dt.hour.value_counts().idxmax())
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


# In[5]:


def station_stats(df):
    start_time = time.time()
    print ('commonly used start station: ', df['Start Station']. value_counts().idxmax())
    print ('commonly used end station: ', df['End Station']. value_counts().idxmax())
    print ('most frequent combination of start and end station: ', df.groupby(['Start Station','End Station']).size().reset_index().rename(columns={0:'count'}).max())
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


# In[6]:


def trip_duration_stats (df):
    start_time = time.time()
    print ('Total travel time: ', df['Trip Duration'].sum())
    print ('Travel mean time: ', df['Trip Duration'].mean())
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


# In[12]:


def user_stats (df):
     start_time = time.time()
     print ('counts of user types:\n ' , df['User Type'].value_counts())
     print ('counts of gender:\n ' , df['Gender'].value_counts())
     print ('earliest year of birth: ' , df['Birth Year'].min())
     print ('most recent year of birth: ' , df['Birth Year'].max())
     print ('most common year of birth: ' , df['Birth Year'].value_counts(). idxmax())   
     print("\nThis took %s seconds." % (time.time() - start_time))
     print('-'*40)


# In[13]:



def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break
            
if __name__ == "__main__":
	main()            


# In[ ]:




